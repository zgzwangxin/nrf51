

#include "battery_voltage_level.h"


#include <string.h>
#include <stdio.h>

#include "nrf_gpio.h"
#include "nrf_drv_adc.h"

#include "ble_bas.h"

#include "app_error.h"
#include "nrf_log.h"
#include "nrf_log_ctrl.h"

#define ADC_BUFFER_SIZE 10                                /**< Size of buffer for ADC samples.  */
static nrf_adc_value_t       adc_buffer[ADC_BUFFER_SIZE]; /**< ADC buffer. */
//static nrf_drv_adc_channel_t m_channel_config = NRF_DRV_ADC_DEFAULT_CHANNEL(NRF_ADC_CONFIG_INPUT_2); /**< Channel instance. Default configuration used. */
static nrf_drv_adc_channel_t m_channel_config = 
{
    {{
        .resolution = NRF_ADC_CONFIG_RES_10BIT,
        .input      = NRF_ADC_CONFIG_SCALING_INPUT_ONE_THIRD,
        .reference  = NRF_ADC_CONFIG_REF_VBG,
        .ain        = NRF_ADC_CONFIG_INPUT_2
    }}, NULL
};

int set_ble_battery_level(uint8_t battery_level);

/**
 * @brief ADC interrupt handler.
 */
static void adc_event_handler(nrf_drv_adc_evt_t const * p_event)
{
    if (p_event->type == NRF_DRV_ADC_EVT_DONE)
    {
        uint32_t i;
        uint32_t ad_sum = 0;
        uint16_t ad_value;
        float fvoltage ;
        for (i = 0; i < p_event->data.done.size; i++)
        {
         //   NRF_LOG_INFO("Current sample value: %d\r\n", p_event->data.done.p_buffer[i]);
            
            ad_sum += p_event->data.done.p_buffer[i];
        }
        ad_value = ad_sum / p_event->data.done.size;
        
        fvoltage = ad_value * 1.2 / ((0x01 << 10) - 1) * 3 * 2;
        
        fvoltage  =  fvoltage / 7.2 * 100;
        
        nrf_gpio_pin_write(ADC_ON_PIN_NUMBER, ADC_ON_ACTIVE_LEVEL ? 0 : 1);
        
        set_ble_battery_level(fvoltage);
    }
}

/**
 * @brief ADC initialization.
 */
static void adc_config(void)
{
    ret_code_t ret_code;
    nrf_drv_adc_config_t config = NRF_DRV_ADC_DEFAULT_CONFIG;

    ret_code = nrf_drv_adc_init(&config, adc_event_handler);
    APP_ERROR_CHECK(ret_code);

    nrf_drv_adc_channel_enable(&m_channel_config);
}


battery_voltage_manage_t    g_battery_voltage_manage;

 
int battery_voltage_init(battery_voltage_manage_t *p_battery_voltage_manage)
{
    if (p_battery_voltage_manage == NULL)
    {
        return 1;
    }
    p_battery_voltage_manage->state =   BATTERY_VOLTAGE_START;
    
    p_battery_voltage_manage->data.sample_cnt   =   0;
    p_battery_voltage_manage->data.sample_N     =   ADC_BUFFER_SIZE;
    
    p_battery_voltage_manage->data.start_wait_timeout_cnt  =   0;
    p_battery_voltage_manage->data.start_wait_timeout_N  =   1;
    
    p_battery_voltage_manage->data.sample_wait_timeout_cnt  =   0;
    p_battery_voltage_manage->data.sample_wait_timeout_N    =   11;
    
    p_battery_voltage_manage->data.restart_wait_timeout_cnt =   0;
    p_battery_voltage_manage->data.restart_wait_timeout_N   =   10 * 100;   // 10 S
    
    adc_config();
    
    return 0;
}


int battery_voltage_check_state(battery_voltage_manage_t *p_battery_voltage_manage)
{
    if (p_battery_voltage_manage == NULL)
    {
        return 1;
    }
    
    switch (p_battery_voltage_manage->state)
    {
        case BATTERY_VOLTAGE_START:
            
            nrf_gpio_pin_write(ADC_ON_PIN_NUMBER, ADC_ON_ACTIVE_LEVEL ? 1 : 0);
        
            APP_ERROR_CHECK(nrf_drv_adc_buffer_convert(adc_buffer,ADC_BUFFER_SIZE));
        
            p_battery_voltage_manage->data.sample_cnt               =   0;
            p_battery_voltage_manage->data.start_wait_timeout_cnt   =   0;
            p_battery_voltage_manage->data.sample_wait_timeout_cnt  =   0;
            p_battery_voltage_manage->data.restart_wait_timeout_cnt =   0;
            
            p_battery_voltage_manage->state = BATTERY_VOLTAGE_AD_START_WAIT;
            
            break;
    
        case BATTERY_VOLTAGE_AD_START_WAIT:
            p_battery_voltage_manage->data.start_wait_timeout_cnt++;
            if (p_battery_voltage_manage->data.start_wait_timeout_cnt >= 
                p_battery_voltage_manage->data.start_wait_timeout_N
            )
            {
                p_battery_voltage_manage->data.start_wait_timeout_cnt = 0;
                
                p_battery_voltage_manage->state = BATTERY_VOLTAGE_AD_SAMPLE;
                
            }
            break;
        
        case BATTERY_VOLTAGE_AD_SAMPLE:
            
            p_battery_voltage_manage->data.sample_cnt ++;
        
            nrf_drv_adc_sample();
            p_battery_voltage_manage->data.sample_wait_timeout_cnt  =   0;
            
            p_battery_voltage_manage->state = BATTERY_VOLTAGE_AD_SAMPLE_WAIT;
        
            break;
        
        case BATTERY_VOLTAGE_AD_SAMPLE_WAIT:
            
            p_battery_voltage_manage->data.sample_wait_timeout_cnt ++;
        
            if (p_battery_voltage_manage->data.sample_wait_timeout_cnt >=
                p_battery_voltage_manage->data.sample_wait_timeout_N
            )
            {
                p_battery_voltage_manage->data.sample_wait_timeout_cnt = 0;
                
                if (p_battery_voltage_manage->data.sample_cnt >=
                    p_battery_voltage_manage->data.sample_N
                ) 
                {
                    p_battery_voltage_manage->data.sample_cnt = 0;
                    
                    p_battery_voltage_manage->state = BATTERY_VOLTAGE_AD_RESTART_WAIT;
                }
                else
                {
                    p_battery_voltage_manage->state = BATTERY_VOLTAGE_AD_SAMPLE;
                }
            }
            
            break;
        
        case BATTERY_VOLTAGE_AD_RESTART_WAIT:
            
            p_battery_voltage_manage->data.restart_wait_timeout_cnt++;
            if (p_battery_voltage_manage->data.restart_wait_timeout_cnt >=
                p_battery_voltage_manage->data.restart_wait_timeout_N
            )
            {
                p_battery_voltage_manage->data.restart_wait_timeout_cnt = 0;
                
                p_battery_voltage_manage->state = BATTERY_VOLTAGE_START;
                
                nrf_gpio_pin_write(ADC_ON_PIN_NUMBER, ADC_ON_ACTIVE_LEVEL ? 0 : 1);
            }
        
            break;
    
        default:
            break;
    }
    
    return 0;
}
